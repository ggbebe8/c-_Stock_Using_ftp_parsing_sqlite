# c-_Stock_Using_ftp_parsing_sqlite

 주식투자 과정에서 매수/매도 내역 관리
1. sqlite를 이용해 데이터 관리
2. 1분 단위로 네이버 주식 파싱
3. ftp를 이용해 서버와 데이터 동기화
4. ftp아이디 비밀번호 암호화
5. Ctrl + z를 이용한 숨김 및 표시 
6. Ctrl + q를 이용한 종료
7. ini 파일로 옵션 관리. 
